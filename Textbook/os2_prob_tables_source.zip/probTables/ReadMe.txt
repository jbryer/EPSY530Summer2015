The probability table files and figures were originally created by members of the OpenIntro project (openintro.org), and these files are released under the following license:

- Creative Commons BY-NC-SA 3.0 license
  http://creativecommons.org/licenses/by-nc-sa/3.0/

No attribution is necessary beyond retaining this ReadMe file with any source files distributed. No attribution is necessary for PDF distributions.