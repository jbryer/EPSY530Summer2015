# NOTE
# The output will include a backslash preceding each { and }
#   and it will be missing a backslash before each "scriptsize"
# Copy the output into a text editor and then use Find/Replace:
#   1. Replace all "\{" with "{"
#   2. Replace all "\}" with "}"
#   3. Replace all "scriptsize" with "\scriptsize"


library(xtable)

#_____ negative Z table _____#
z <- matrix(NA, 39, 10)
for(i in 1:39){
	for(j in 1:9){
		z[i,j] <- -((39-i)/10 + (10-j)/100)+0.01
	}
}
Z <- matrix(NA, 39, 10)
for(i in 1:39){
	for(j in 1:9){
		hold <- format(c(round(pnorm(z[i,j]), 4), 0.1234))[1]
		Z[i,j] <- paste('scriptsize{', hold, '}', sep='')
	}
	hold <- format(c(z[i,9], 0.1))[1]
	Z[i,10] <- paste('$', hold, '$', sep='')
}
hold <- as.character(format(c(round(pnorm(seq(-3.89, -0.09, 0.1)),4),0.0001))[1:39])
rownames(Z) <- paste('scriptsize{', hold, '}', sep='')
colnames(Z) <- format(seq(0.08,-0.01,-0.01))
xtable(Z[5:39,])


#_____ positive Z table _____#
z <- matrix(NA, 39, 10)
for(i in 1:39){
	for(j in 1:10){
		z[i,j] <- (i-1)/10 + (j-1)/100
	}
}
Z <- matrix(NA, 39, 10)
for(i in 1:39){
	for(j in 1:10){
		hold <- format(c(round(pnorm(z[i,j]), 4), 0.1234))[1]
		Z[i,j] <- paste('scriptsize{', hold, '}', sep='')
	}
}
hold <- as.character(format(seq(0, 3.8, 0.1)))
rownames(Z) <- hold
colnames(Z) <- format(seq(0,0.09,0.01))
xtable(Z[1:35,])

